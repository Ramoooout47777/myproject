<img src="{{asset('images/logo.png')}}" alt="" style="height: 50px;">
