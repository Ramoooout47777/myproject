<div>
    <!-- Because you are alive, everything is possible. - Thich Nhat Hanh -->
</div>
